# Azure Purview - Data Ingestion Series

Learning Azure Purview services in Azure Cloud, Designed an archirecture and implementing that architecture with the services Dropbox, Azure Logic Apps, Azure Data Factory and Azure SQL Databases.


## Code Description


    There are no codes associated with this project.  Everything is via UI based.

